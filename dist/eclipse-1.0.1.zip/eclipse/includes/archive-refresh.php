<?php
if (!isset($_CONF) || empty($_CONF['path_data'])) { return; }
$eclipseBuildId = '1.0.1-34001834139';
$eclipseMarker = rtrim($_CONF['path_data'], '/\\') . DIRECTORY_SEPARATOR . 'eclipse-build-id.txt';
$eclipsePrevious = @file_get_contents($eclipseMarker);
if (trim((string) $eclipsePrevious) !== $eclipseBuildId) {
    if (function_exists('CTL_clearCache')) { CTL_clearCache(); }
    @file_put_contents($eclipseMarker, $eclipseBuildId . PHP_EOL, LOCK_EX);
}
