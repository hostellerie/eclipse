<?php

if (!defined('VERSION')) {
    die('This file can not be used on its own!');
}

function eclipse_update_upload_error_message($error)
{
    $error = (int) $error;
    if ($error === UPLOAD_ERR_INI_SIZE) {
        $limit = ini_get('upload_max_filesize');
        return 'The ZIP exceeds the server upload_max_filesize limit' . ($limit ? ' (' . $limit . ')' : '') . '.';
    }
    if ($error === UPLOAD_ERR_FORM_SIZE) return 'The ZIP exceeds the upload limit declared by the form.';
    if ($error === UPLOAD_ERR_PARTIAL) return 'The ZIP was only partially uploaded. Please try again.';
    if ($error === UPLOAD_ERR_NO_FILE) return 'No ZIP file was received.';
    if (defined('UPLOAD_ERR_NO_TMP_DIR') && $error === UPLOAD_ERR_NO_TMP_DIR) return 'The server temporary upload directory is missing.';
    if (defined('UPLOAD_ERR_CANT_WRITE') && $error === UPLOAD_ERR_CANT_WRITE) return 'The server could not write the uploaded ZIP to disk.';
    if (defined('UPLOAD_ERR_EXTENSION') && $error === UPLOAD_ERR_EXTENSION) return 'A PHP extension stopped the ZIP upload.';
    return 'The ZIP upload failed with PHP upload error ' . $error . '.';
}

function eclipse_install_uploaded_update($upload)
{
    global $_CONF;
    $fail = function ($message) { return array('success' => false, 'message' => $message); };
    if (!class_exists('ZipArchive')) return $fail('The PHP ZipArchive extension is not available.');
    if (!is_array($upload) || !isset($upload['error'])) return $fail('No ZIP upload was received.');
    if ((int) $upload['error'] !== UPLOAD_ERR_OK) return $fail(eclipse_update_upload_error_message($upload['error']));
    if (empty($upload['tmp_name']) || !is_uploaded_file($upload['tmp_name'])) return $fail('The uploaded file could not be verified.');
    if (empty($upload['size']) || $upload['size'] > 20971520) return $fail('The archive must be smaller than 20 MB.');
    if (!preg_match('/\.zip$/i', isset($upload['name']) ? $upload['name'] : '')) return $fail('Only ZIP archives are accepted.');
    $dataDir = !empty($_CONF['path_data']) ? rtrim($_CONF['path_data'], '/\\') : '';
    if ($dataDir === '' || !is_dir($dataDir) || !is_writable($dataDir)) return $fail('The Geeklog data directory is missing or not writable.');
    $workRoot = $dataDir . DIRECTORY_SEPARATOR . 'eclipse-updates';
    if (!is_dir($workRoot) && !@mkdir($workRoot, 0750, true)) return $fail('Unable to create data/eclipse-updates.');
    $job = $workRoot . DIRECTORY_SEPARATOR . 'update-' . date('Ymd-His') . '-' . substr(sha1(uniqid('', true)), 0, 8);
    if (!@mkdir($job, 0750, true)) return $fail('Unable to create the temporary update directory.');
    $zip = new ZipArchive();
    if ($zip->open($upload['tmp_name']) !== true) return $fail('The uploaded archive is not a readable ZIP file.');

    $packageMarker = 'eclipse/ECLIPSE_THEME_PACKAGE.txt';
    $markerData = false;
    if (method_exists($zip, 'getFromName')) {
        $markerData = $zip->getFromName($packageMarker);
    } elseif (method_exists($zip, 'getStream')) {
        $markerStream = $zip->getStream($packageMarker);
        if (is_resource($markerStream)) {
            $markerData = stream_get_contents($markerStream);
            fclose($markerStream);
        }
    }
    if (!is_string($markerData) || strlen($markerData) > 1024
        || !preg_match('/^package_type=geeklog-theme$/m', $markerData)
        || !preg_match('/^theme=eclipse$/m', $markerData)
        || !preg_match('/^format=1$/m', $markerData)) {
        $zip->close(); eclipse_remove_tree($job);
        return $fail('This is not an official Eclipse theme package or its package marker is invalid.');
    }

    $allowed = '/\.(?:php|ini|thtml|thtmlx|css|js|json|md|txt|html|svg|png|jpe?g|gif|ico)$/i';
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = str_replace('\\', '/', (string) $zip->getNameIndex($i));
        if ($name === '' || strpos($name, "\0") !== false || $name[0] === '/' || preg_match('#(^|/)\.\.(/|$)#', $name) || strpos($name, 'eclipse/') !== 0) {
            $zip->close(); eclipse_remove_tree($job); return $fail('Unsafe or unexpected path in the archive: ' . $name);
        }
        if (substr($name, -1) === '/') continue;
        if (!preg_match($allowed, $name)) {
            $zip->close(); eclipse_remove_tree($job); return $fail('File type not allowed in the archive: ' . $name);
        }
        if (method_exists($zip, 'getExternalAttributesIndex')) {
            $opsys = 0; $attr = 0;
            if ($zip->getExternalAttributesIndex($i, $opsys, $attr) && (($attr >> 16) & 0170000) === 0120000) {
                $zip->close(); eclipse_remove_tree($job); return $fail('Symbolic links are not allowed in updates.');
            }
        }
        $target = $job . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $name);
        $parent = dirname($target);
        if (!is_dir($parent) && !@mkdir($parent, 0750, true)) {
            $zip->close(); eclipse_remove_tree($job); return $fail('Unable to prepare the temporary update tree.');
        }
        $source = $zip->getStream($zip->getNameIndex($i));
        $destination = @fopen($target, 'wb');
        if (!$source || !$destination) {
            if (is_resource($source)) fclose($source); if (is_resource($destination)) fclose($destination);
            $zip->close(); eclipse_remove_tree($job); return $fail('Unable to extract ' . $name);
        }
        stream_copy_to_stream($source, $destination); fclose($source); fclose($destination);
    }
    $zip->close();
    $sourceTheme = $job . DIRECTORY_SEPARATOR . 'eclipse';
    $manifest = $sourceTheme . DIRECTORY_SEPARATOR . 'theme.ini';
    $functions = $sourceTheme . DIRECTORY_SEPARATOR . 'functions.php';
    if (!is_file($manifest) || !is_file($functions)) { eclipse_remove_tree($job); return $fail('The ZIP does not contain a complete eclipse/ theme.'); }
    $ini = @parse_ini_file($manifest, true);
    $newVersion = isset($ini['theme']['version']) ? $ini['theme']['version'] : '';
    if (!preg_match('/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/', $newVersion)) { eclipse_remove_tree($job); return $fail('The archive has no valid Eclipse version.'); }
    $integrityError = eclipse_verify_package_manifest($sourceTheme, $newVersion);
    if ($integrityError !== '') { eclipse_remove_tree($job); return $fail($integrityError); }
    $themeDir = dirname(__DIR__);
    if (!is_dir($themeDir) || !is_writable($themeDir)) { eclipse_remove_tree($job); return $fail('The eclipse theme directory is not writable by PHP.'); }
    $backupRoot = eclipse_persistent_root();
    if ($backupRoot === '' || (!is_dir($backupRoot) && !@mkdir($backupRoot, 0750, true))) { eclipse_remove_tree($job); return $fail('Unable to create the persistent Eclipse backup directory.'); }
    $backup = $backupRoot . DIRECTORY_SEPARATOR . 'eclipse-' . date('Ymd-His');
    if (!eclipse_copy_tree($themeDir, $backup, 0750, 0640)) { eclipse_remove_tree($job); return $fail('Unable to create the safety backup. No update was applied.'); }

    $themeParent = dirname($themeDir);
    if (!is_dir($themeParent) || !is_writable($themeParent)) { eclipse_remove_tree($job); return $fail('The layout directory is not writable by PHP.'); }
    $switchId = date('Ymd-His') . '-' . substr(sha1(uniqid('', true)), 0, 8);
    $preparedTheme = $themeParent . DIRECTORY_SEPARATOR . '.eclipse-new-' . $switchId;
    $retiredTheme = $themeParent . DIRECTORY_SEPARATOR . '.eclipse-old-' . $switchId;

    if (file_exists($preparedTheme) || file_exists($retiredTheme)) { eclipse_remove_tree($job); return $fail('Unable to prepare a unique Eclipse replacement directory.'); }
    if (!eclipse_copy_tree($sourceTheme, $preparedTheme, 0755, 0644)) {
        eclipse_remove_tree($preparedTheme); eclipse_remove_tree($job);
        return $fail('Unable to prepare the new Eclipse theme directory. The current theme was not changed.');
    }
    $preparedIntegrityError = eclipse_verify_package_manifest($preparedTheme, $newVersion);
    if ($preparedIntegrityError !== '') {
        eclipse_remove_tree($preparedTheme); eclipse_remove_tree($job);
        return $fail('Prepared Eclipse directory failed integrity verification: ' . $preparedIntegrityError);
    }

    if (!@rename($themeDir, $retiredTheme)) {
        eclipse_remove_tree($preparedTheme); eclipse_remove_tree($job);
        return $fail('Unable to move the current Eclipse directory aside. The current theme was not changed.');
    }
    if (!@rename($preparedTheme, $themeDir)) {
        $restored = @rename($retiredTheme, $themeDir);
        eclipse_remove_tree($preparedTheme); eclipse_remove_tree($job);
        return $fail($restored
            ? 'Unable to activate the new Eclipse directory. The previous theme was restored automatically.'
            : 'Unable to activate the new Eclipse directory and automatic restoration failed. Restore the latest persistent Eclipse backup.');
    }

    $installedError = eclipse_verify_installed_manifest($themeDir);
    if ($installedError !== '') {
        eclipse_remove_tree($retiredTheme);
        eclipse_remove_tree($job);
        return $fail($installedError . ' Restore the latest persistent Eclipse backup.');
    }

    $touchedTemplates = eclipse_touch_installed_templates($themeDir);

    eclipse_remove_tree($retiredTheme);
    eclipse_remove_tree($job);
    $cacheMessage = eclipse_clear_theme_cache()
        ? ' Geeklog template and generated CSS caches were cleared.'
        : ' Geeklog template/CSS caches could not be cleared automatically.';

    return array(
        'success' => true,
        'message' => 'Eclipse ' . $newVersion
            . ' installed successfully and verified at ' . $themeDir . '.'
            . $cacheMessage
            . ($touchedTemplates === false
                ? ' Template timestamps could not be refreshed.'
                : ' Refreshed ' . (int) $touchedTemplates . ' template timestamp(s).')
            . ' PHP OPcache entries were invalidated when supported.'
    );
}

function eclipse_touch_installed_templates($themeRoot)
{
    $themeRoot = rtrim((string) $themeRoot, "/\\");
    if ($themeRoot === '' || !is_dir($themeRoot)) {
        return false;
    }

    $timestamp = time() + 2;
    $count = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($themeRoot, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if (!$file->isFile() || $file->isLink()) {
            continue;
        }

        $extension = strtolower(pathinfo($file->getFilename(), PATHINFO_EXTENSION));
        if ($extension !== 'thtml' && $extension !== 'thtmlx') {
            continue;
        }

        if (!@touch($file->getPathname(), $timestamp)) {
            return false;
        }
        $count++;
    }

    return $count;
}

function eclipse_verify_installed_manifest($themeRoot)
{
    $manifestPath = rtrim($themeRoot, "/\\") . DIRECTORY_SEPARATOR . 'MANIFEST.json';
    if (!is_file($manifestPath)) {
        return 'Installed Eclipse manifest is missing.';
    }

    $manifest = json_decode(@file_get_contents($manifestPath), true);
    if (!is_array($manifest) || !isset($manifest['files']) || !is_array($manifest['files'])) {
        return 'Installed Eclipse manifest is invalid.';
    }

    foreach ($manifest['files'] as $relative => $hash) {
        $relative = str_replace('\\', '/', (string) $relative);
        if ($relative === '' || $relative === 'MANIFEST.json') {
            continue;
        }

        $path = rtrim($themeRoot, "/\\") . DIRECTORY_SEPARATOR
            . str_replace('/', DIRECTORY_SEPARATOR, $relative);

        if (!is_file($path) || strtolower(hash_file('sha256', $path)) !== strtolower((string) $hash)) {
            return 'Installed Eclipse file verification failed for ' . $relative . '.';
        }

        if (substr($relative, -4) === '.php'
            && function_exists('opcache_invalidate')) {
            @opcache_invalidate($path, true);
        }
    }

    return '';
}

function eclipse_verify_package_manifest($themeRoot, $expectedVersion)
{
    $manifestPath = $themeRoot . DIRECTORY_SEPARATOR . 'MANIFEST.json';
    if (!is_file($manifestPath)) return 'The Eclipse package integrity manifest is missing.';
    $manifest = json_decode(@file_get_contents($manifestPath), true);
    if (!is_array($manifest) || !isset($manifest['version'], $manifest['algorithm'], $manifest['files']) || $manifest['version'] !== $expectedVersion || strtolower($manifest['algorithm']) !== 'sha256' || !is_array($manifest['files'])) return 'The Eclipse package integrity manifest is invalid.';
    $expected = array();
    foreach ($manifest['files'] as $relative => $hash) {
        $relative = str_replace('\\', '/', (string) $relative);
        if ($relative === '' || $relative === 'MANIFEST.json' || $relative[0] === '/' || strpos($relative, '../') !== false || !preg_match('/^[0-9A-Za-z._\/-]+$/', $relative) || !preg_match('/^[0-9a-f]{64}$/i', $hash)) return 'The Eclipse package integrity manifest contains an unsafe entry.';
        $path = $themeRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
        if (!is_file($path) || strtolower(hash_file('sha256', $path)) !== strtolower($hash)) return 'Package integrity check failed for ' . $relative . '.';
        $expected[$relative] = true;
    }
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($themeRoot, FilesystemIterator::SKIP_DOTS));
    foreach ($iterator as $file) {
        if (!$file->isFile() || $file->isLink()) continue;
        $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($themeRoot) + 1));
        if ($relative !== 'MANIFEST.json' && !isset($expected[$relative])) return 'Unexpected file missing from the integrity manifest: ' . $relative . '.';
    }
    return '';
}

function eclipse_copy_tree($source, $destination, $directoryMode = 0750, $fileMode = 0640)
{
    if (!is_dir($destination) && !@mkdir($destination, $directoryMode, true)) return false;
    @chmod($destination, $directoryMode);
    $handle = @opendir($source); if (!$handle) return false;
    $ok = true;
    while (($name = readdir($handle)) !== false) {
        if ($name === '.' || $name === '..') continue;
        $from = $source . DIRECTORY_SEPARATOR . $name; $to = $destination . DIRECTORY_SEPARATOR . $name;
        if (is_link($from)) { $ok = false; break; }
        if (is_dir($from)) { if (!eclipse_copy_tree($from, $to, $directoryMode, $fileMode)) { $ok = false; break; } }
        elseif (!@copy($from, $to)) { $ok = false; break; }
        else { @chmod($to, $fileMode); }
    }
    closedir($handle); return $ok;
}

function eclipse_remove_tree($path)
{
    if (!is_dir($path) || is_link($path)) return;
    $handle = @opendir($path); if (!$handle) return;
    while (($name = readdir($handle)) !== false) {
        if ($name === '.' || $name === '..') continue;
        $item = $path . DIRECTORY_SEPARATOR . $name;
        if (is_dir($item) && !is_link($item)) eclipse_remove_tree($item); else @unlink($item);
    }
    closedir($handle); @rmdir($path);
}
